VECTOROPS LIVE DRIVER - INSTALLATION

Upload these files/folders to the ROOT of the existing VectorOps GitHub repository:

  index.html
  driver.html
  package.json
  api/
    publish-route.js
    driver-routes.js
    route-action.js

IMPORTANT
- index.html is the updated VectorOps dispatcher build.
- driver.html replaces the earlier vectorops_driver_phase1.html mobile prototype.
- The api folder must remain named exactly "api".
- Keep the API JavaScript filenames exactly as provided.
- package.json must be at the repository root.
- Vercel already has VECTOROPS_DB_DATABASE_URL configured, so no database secret should be placed in GitHub.

EXPECTED URLS AFTER VERCEL DEPLOYS
  Dispatcher: https://YOUR-DOMAIN/
  Driver:     https://YOUR-DOMAIN/driver.html
  API test:   https://YOUR-DOMAIN/api/driver-routes?driver=Test

FIRST LIVE TEST
1. Push all files to the main branch and wait for Vercel deployment to be Ready.
2. Open VectorOps and import a normal route.
3. Open Route Details > Assign to Driver.
4. Enter a distinctive test driver name, for example: Test Driver.
5. Click Publish to Driver.
6. Open /driver.html on the phone.
7. Enter exactly the same driver name and press LOAD.
8. Open the route and test START ROUTE, ARRIVED, and COMPLETE STOP.
9. In Neon Data Editor, verify routes, route_stops, and route_events are receiving data.

The JSON download option remains available as a fallback.
